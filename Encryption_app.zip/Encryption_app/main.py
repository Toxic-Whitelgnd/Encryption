from tkinter import*
from tkinter import ttk
from tkinter import messagebox,filedialog
import encryption_form
import decryption_form
import datetime
import pyttsx3


class window1:

    def __init__(self,master):
            self.master=master
            self.master.resizable(False, False)
            self.master.geometry("300x350")
            self.master.title("#Login#")
            self.master.iconbitmap("icon/login.ico")
            #STYLING
            self.style = ttk.Style()

            self.style.configure('frame_header.TLabel',background='#0981d6')
            self.style.configure('frame_body.TLabel', background='#0981d6')

            #need to create two frames one is for user @ pass and anoter for labeling
            self.frame_header=ttk.Frame(self.master)

            self.frame_body = ttk.Frame(self.master,style='frame_header.TLabel')


            self.label_header=ttk.Label(self.frame_header,text="  User Login ",font=('Ravie',16,'bold'),style='frame_header.TLabel')
            self.img=PhotoImage(file="img_window1/rsz_rsz_login.gif")
            self.label_header1=ttk.Label(self.frame_header,image=self.img,background='#0981d6',borderwidth=12)

            self.label_design=ttk.Label(self.frame_header,text="------------------------------------------------")

            self.img1=PhotoImage(file="img_window1/rsz_2018-02-09data-encryption.gif")
            self.label_body1=ttk.Label(self.frame_body,image=self.img1)
            self.label_usr=ttk.Label(self.frame_body,text="USERNAME:",style='frame_body.TLabel',font=('Forte'))
            self.label_pass = ttk.Label(self.frame_body, text="PASSWORD:",style='frame_body.TLabel',font=('Forte'))

            self.label_design1 = ttk.Label(self.frame_body, text="----------------------------------------------")


            #gridding the labels and headeer
            self.frame_header.pack()
            self.frame_body.pack()
            self.label_header1.grid(row=0, rowspan=1, column=0,sticky='nw')
            self.label_header.grid(row=0,column=0,sticky='e',padx=20)

            self.label_design.grid(row=1,column=0)
            self.label_design1.grid(row=2,columnspan=2,pady=5)
            self.label_usr.grid(row=0,column=0,padx=4,pady=30)
            self.label_pass.grid(row=1,column=0,padx=4,pady=30)
            self.label_body1.place(x=0,y=0)
        #creasting entry for user and password

            self.usr_entry=ttk.Entry(self.frame_body,width=20)
            self.usr_pass = ttk.Entry(self.frame_body, width=20,show='#')

        #griding the entry of usr and pass

            self.usr_entry.grid(row=0,column=1)
            self.usr_pass.grid(row=1, column=1)
        #creating a image for the button
            self.btn_login_img=PhotoImage(file='img_window1/rsz_1log1.gif').subsample(2,2)
            self.btn_reset_img = PhotoImage(file='img_window1/rsz_reset.gif').subsample(2,2)
            self.btn_quit_img = PhotoImage(file='img_window1/rsz_qiut.gif').subsample(2,2)


        #creating a button

            self.btn_login = Button(self.frame_body,text="Login",image=self.btn_login_img,bg='red',fg='white'
                                    ,activebackground='orange',
                                    compound=RIGHT,command=self.login,font=('Forte'),cursor="watch")
            self.btn_clear = Button(self.frame_body, text="Reset",command=self.reset,image=self.btn_reset_img
                                    ,bg='orange',fg='white',activebackground='blue'
                                    ,font=('Forte'),compound=RIGHT,cursor="arrow")
            self.btn_quit = Button(self.frame_body, text="Quit", command=self.quit_,image=self.btn_quit_img
                                   ,bg='blue',fg='white',activebackground='red'
                                   ,font=('Forte'),compound=RIGHT,cursor="pirate")

        #griding the button

            self.btn_login.grid(row=3,column=0,padx=20,pady=10)
            self.btn_clear.grid(row=3, column=1,padx=20,pady=10,sticky='e')
            self.btn_quit.grid(row=4,columnspan=2,sticky='n')

        #creating a bot for speaking

            self.speak_1()

        #creating a hover structure
            self.btn_clear.bind("<Enter>",self.hover_enter_clear)
            self.btn_clear.bind("<Leave>", self.hover_leave_clr)

            self.btn_login.bind("<Enter>", self.hover_enter_login)
            self.btn_login.bind("<Leave>", self.hover_leave_log)

            self.btn_quit.bind("<Enter>", self.hover_enter_quit)
            self.btn_quit.bind("<Leave>", self.hover_leave_quit)


    def login(self):
        self.a=self.usr_entry.get()
        self.b=self.usr_pass.get()
        if(self.a == 'akatsuki'):
            if(self.b == 'itachi'):
                self.new_window()
            else:
                messagebox.showinfo(title="incorrect password" ,message="Check your password!")
        else:
            messagebox.showinfo(title="incorrect login info", message="Check your Login info")



    def reset(self):
        self.usr_entry.delete(0,END)
        self.usr_pass.delete(0, END)

    def quit_(self):
        self.master.quit()

    def new_window(self):
       # self.frame_body.destroy()
       # self.frame_header.destroy()

        self.newwindow=Toplevel(self.master)
        self.app=window2(self.newwindow)

        self.engine = pyttsx3.init()
        self.engine.say("Your Login is successful Now please select your option that u have to perform! Thank you!")
        self.engine.runAndWait()

    def speak_1(self):
        self.engine = pyttsx3.init()
        self.engine.say( "Hello user! welcome to the Login page Please enter your Login details.")
        self.engine.runAndWait()

    #creating a hover function

    def hover_enter_clear(self,event):
        print("entered")
        self.btn_clear["bg"]="yellow"
    def hover_leave_clr(self,event):
        print("leaved")
        self.btn_clear["bg"]="orange"



    def hover_enter_login(self,event):
        self.btn_login["bg"] = "#146cfa"  # blue
    def hover_leave_log(self,event):
        self.btn_login["bg"] = "red"


    def hover_enter_quit(self,event):
        self.btn_quit["bg"] = "#fa0f32"  # reed like pink
    def hover_leave_quit(self,event):
        self.btn_quit["bg"] = "blue"




#need to take from here
class window2:
    def __init__(self,master):
        self.master = master
        self.master.resizable(False, False)
        self.frame = ttk.Frame(self.master).pack()
        self.master.geometry("640x520")
        self.master.title("#selection#")

        #crreating a styles for window2
        self.style=ttk.Style()

        self.style.configure('frame_header.TLabel',background='blue')
        self.style.configure('frame_body.TLabel',background='#24e34a')

        self.style.configure('frame_body1.TButton',background='#24e34a')
        self.style.configure('frame_body1.TButton', background='#24e34a')
        self.style.configure('frame_body1.TButton', background='#24e34a')




        #start code here

        self.frame_header = ttk.Frame(self.master)

        self.frame_body = ttk.Frame(self.master,style='frame_body.TLabel')

        #using images

        self.encr_img=PhotoImage(file="img_window2/rsz_1rsz_heade_back.gif") #make the header with aa diagram
        self.imf_header=ttk.Label(self.frame_header,image=self.encr_img)
        self.imf_header.grid(row=0,column=1)
        self.back_grod = PhotoImage(file='img_window2/rsz_wallpaperflarecom_wallpaper.gif')
        self.img_label = ttk.Label(self.frame_body, image=self.back_grod)
        self.img_label.place(x=0, y=0)


        self.label_header = ttk.Label(self.frame_header,style='frame_header.TLabel',text="ENCRYPTION AND DECRYPTION"
                                      , font=('Arial', 20, 'bold'))


        self.label_design = ttk.Label(self.frame_header, text="            ------------------------------------------------ "
                                                              "       ---------------------------------------- "
                                      ,background='blue')

        self.label_content=ttk.Label(self.frame_body,style='frame_body.TLabel',text="      Select the option that   "
                                    "the operation that u have to perform !     ",font=(
            'Arial',16))

        #creating a images for buttons and configuration!

        self.btn_encryp=PhotoImage(file='img_window2/rsz_download.gif')
        self.btn_decryp = PhotoImage(file='img_window2/rsz_download_1.gif')
        self.btn_quit = PhotoImage(file='img_window2/rsz_qiut.gif')

        #creating a button for encryption and decryption
        self.encry_btn=Button(self.frame_body,text="ENCRYPTION",bg='#00f024',fg='white',activebackground='red'
                    ,image=self.btn_encryp,padx=4,compound=RIGHT,command=self.encrypt,font='Ravie')
        self.decry_btn = Button(self.frame_body, text="DECRYPTION", bg='#29bf23', fg='white',command=self.decrypt
                      ,image=self.btn_decryp,padx=4,compound=RIGHT, activebackground='red',font='Ravie')
        self.quit = Button(self.frame_body, text="QUIT", bg='#0a6e06', fg='white', activebackground='#d400a2',
                   image=self.btn_quit,padx=5,compound=RIGHT,command=self.quit_,font='Ravie',cursor="pirate")

        #creating about label
        self.abt=ttk.Label(self.frame_body,text="Developed by:- "
                                                "  Akatsuki Organisation and development   ",font='Ravie',background='black',foreground='red')


        #creating a hover structure
        self.encry_btn.bind("<Enter>",self.hover_enter_encryp)
        self.encry_btn.bind("<Leave>",self.hover_leave_encryp)

        self.decry_btn.bind("<Enter>", self.hover_enter_decryp)
        self.decry_btn.bind("<Leave>", self.hover_leave_decryp)

        self.quit.bind("<Enter>", self.hover_enter_quit)
        self.quit.bind("<Leave>", self.hover_leave_quit)


        #gridding
        self.frame_header.pack()
        self.frame_body.pack()


        self.label_header.grid(row=0, column=0)
        self.label_design.grid(row=1, column=0)
        self.label_content.grid(row=0,column=0)

        self.encry_btn.grid(row=1,column=0,padx=0,pady=40,ipadx=5,ipady=5)
        self.decry_btn.grid(row=2, column=0, padx=0, pady=40,ipadx=5,ipady=5)
        self.quit.grid(row=3, column=0, padx=0, pady=40,ipadx=5,ipady=5)

        self.abt.grid(row=4,column=0,padx=4)

    def quit_(self):
        self.master.quit()
        self.engine = pyttsx3.init()
        self.engine.say("Thank you for using this app!have a great day!.")
        self.engine.runAndWait()


    def encrypt(self):
        self.enc = Toplevel(self.master)
        self.app = encryption(self.enc)

    def decrypt(self):
        self.dec = Toplevel(self.master)
        self.app = decryption(self.dec)

    #creating a hover function
    def hover_enter_encryp(self,event):
        self.encry_btn["bg"]="#00ff12"
    def hover_leave_encryp(self,event):
        self.encry_btn["bg"]="#29bf23"

    def hover_enter_decryp(self,event):
        self.decry_btn["bg"]="#00ff12"
    def hover_leave_decryp(self,event):
        self.decry_btn["bg"]="#00ad1a"

    def hover_enter_quit(self,event):
        self.quit["bg"]="#00ff12"
    def hover_leave_quit(self,event):
        self.quit["bg"]="#0a6e06"


class encryption:
    def __init__(self,master):
        print("encryption part entered")
        self.master=master
        self.master.geometry("410x310")
        self.master.resizable(False, False)
        self.master.title("#Encryption#")


        #creating a label and entry for the encryption
        self.frame_header=ttk.Frame(self.master)
        self.frame_body = ttk.Frame(self.master)

        #creating a background
        self.back_grod = PhotoImage(file='rsz_rdblu4.gif')
        self.img_label = ttk.Label(self.frame_body, image=self.back_grod)
        self.img_label.place(x=0, y=0)

        #creating a styles\
        self.style=ttk.Style()
        self.style.configure("body.TLabel",background='#783af2')
        self.style.configure("design.TLabel",background='#1e0257')
        self.style.configure("header.TLabel",background='blue')
        self.style.configure('TFrame',background='red')

        #creasting icon\
        self.master.iconbitmap('icon/data-encryption-32.ico')


        #creating a label and entry
        self.label_head=ttk.Label(self.frame_header,text="ENCRYPTION!!!",font=('Showcard Gothic',20,'bold'),style='header.TLabel')
        self.img_header=PhotoImage(file='img_window2/rsz_window2_back.gif').subsample(2,2)
        self.img_header_=ttk.Label(self.frame_header,image=self.img_header)

    #    self.label_design=ttk.Label(self.frame_header,text='---------------------------------------------------------' )

        self.label_encrypt=ttk.Label(self.frame_body,text="Text:",style='body.TLabel',font='Stencil')
        self.label_key = ttk.Label(self.frame_body,text="Key:",style='body.TLabel',font='Stencil')
        self.label_encrypted = ttk.Label(self.frame_body,text="Encryted text:",style='body.TLabel',font='Stencil')

        self.entry_encrypt=ttk.Entry(self.frame_body,width=20,font='Georgia')
        self.entry_key = ttk.Entry(self.frame_body, width=20,font='Georgia')
        self.entry_encrypted = ttk.Entry(self.frame_body, width=20,font='Georgia',state="disabled")

        #self.label_design = ttk.Label(self.frame_body, text='-----------------------------------------------------')
  #      self.label_design1 = ttk.Label(self.frame_body,
   #                                  text='--------------------------------------------------------------------')

        #creating a images for butn
        self.generate_img = PhotoImage(file='btn_imges/generate.gif').subsample(2, 2)
        self.clear_img = PhotoImage(file='btn_imges/rsz_reset.gif').subsample(2, 2)
        self.save_img = PhotoImage(file='btn_imges/save.gif').subsample(2, 2)
        self.back_img = PhotoImage(file='btn_imges/back btn.gif').subsample(2, 2)

        #creating a button
        self.encrypt_btn=Button(self.frame_body,text="Generate",command=self.encryption_,bg='red',fg='white',padx=10
                                ,image=self.generate_img,compound=RIGHT,activebackground='#8800d6')
        self.clear_btn = Button(self.frame_body, text="Clear", bg='red',command=self.clear_, fg='white'
                                ,image=self.clear_img,compound=RIGHT,activebackground='#8800d6')
        self.save_btn = Button(self.frame_body, text="Save", bg='red',command=self.save_, fg='white'
                               ,image=self.save_img,compound=RIGHT,activebackground='#8800d6')
        self.back_btn = Button(self.frame_body, text="Back", bg='red', fg='white',command=self.back_,activebackground='#8800d6')
        #creating a hover for button
        self.encrypt_btn.bind("<Enter>",self.hover_enter_encrypt)
        self.encrypt_btn.bind("<Leave>", self.hover_leave_encrypt)

        self.clear_btn.bind("<Enter>", self.hover_enter_clear)
        self.clear_btn.bind("<Leave>", self.hover_leave_clear)

        self.save_btn.bind("<Enter>", self.hover_enter_save)
        self.save_btn.bind("<Leave>", self.hover_leave_save)

        self.back_btn.bind("<Enter>", self.hover_enter_back)
        self.back_btn.bind("<Leave>", self.hover_leave_back)



        #griding and packing
        self.frame_header.pack()
        self.frame_body.pack()

        self.label_head.grid(row=0,column=0)
        self.img_header_.grid(row=0, column=1)
   #     self.label_design.grid(row=1,columnspan=2)

        self.label_encrypt.grid(row=0, column=0,padx=20,pady=20)
        self.label_key.grid(row=1, column=0,padx=20,pady=20)
        self.label_encrypted.grid(row=5, column=1,padx=5,pady=5,ipadx=4,ipady=5,sticky='w')

        self.entry_encrypt.grid(row=0, column=1,padx=20,pady=20)
        self.entry_key.grid(row=1, column=1, padx=20, pady=20)
        self.entry_encrypted.grid(row=6, column=1, padx=5, pady=5,sticky='sw')
    #    self.label_design.grid(row=2,columnspan=3,padx=20,pady=5)
     #   self.label_design1.grid(row=4, columnspan=3, padx=20, pady=5)

        self.encrypt_btn.grid(row=3,column=1,padx=5,pady=10,sticky='n')
        self.clear_btn.grid(row=3, column=1, padx=5, pady=10,sticky='e')
        self.save_btn.grid(row=3, column=0, padx=50, pady=10,sticky='e')
        self.back_btn.grid(row=3, column=0, padx=5, pady=10, sticky='w')
    def encryption_(self):
        print("encrypting part")
        self.a = self.entry_encrypt.get()
        if(self.a ==''):
            self.engine = pyttsx3.init()
            self.engine.say("Please enter a text!!")
            self.engine.runAndWait()



        self.b = str(self.entry_key.get())
        if(self.b ==''):
            self.engine = pyttsx3.init()
            self.engine.say("Please enter a key!!")
            self.engine.runAndWait()

        if(self.a != ''):
           if(self.b != ''):
               self.engine = pyttsx3.init()
               self.engine.say("Your text has been succsessfully Encrypted")
               self.engine.runAndWait()
               self.entry_encrypted.configure(state="enabled")


        self.c = encryption_form.encrypt_(self.a,self.b)
        self.d = self.entry_encrypted.insert(0,self.c)



    def clear_(self):
        print("cleared")
        self.entry_encrypt.delete(0,END)
        self.entry_key.delete(0, END)
        self.entry_encrypted.delete(0, END)
        self.entry_encrypted.configure(state="disabled")

    def save_(self):
        print("successfully saved!")
        print("successfully saved!")
        self.file = filedialog.asksaveasfile(defaultextension='.txt',
                                             filetypes=[("Text file", ".txt"), ("Html file", ".html"),
                                                        ("all files", ".*")])
        self.tim = str(datetime.datetime.now())
        self.filetext_decrypt = str(self.entry_encrypt.get())
        self.filetext_decrypted = str(self.entry_encrypted.get())
        self.file.write("ENRCYPTING TEXT:")
        self.file.write('\n')
        self.file.write(self.filetext_decrypt)
        self.file.write('\n')
        self.file.write('ENCRYPTED TEXT:')
        self.file.write('\n')
        self.file.write(self.filetext_decrypted)
        self.file.write('\n')
        self.file.write(self.tim)
        self.file.close()
    def back_(self):
        self.engine = pyttsx3.init()
        self.engine.say(
            "the back option won't work it is under development please close the current tab and go on furter "
            "process!")
        self.engine.runAndWait()

    #creating a function for hover
    def hover_enter_encrypt(self,event):
        self.encrypt_btn["bg"]="blue"
    def hover_leave_encrypt(self,event):
        self.encrypt_btn["bg"]="red"

    def hover_enter_clear(self, event):
        self.clear_btn["bg"] = "blue"
    def hover_leave_clear(self, event):
        self.clear_btn["bg"] = "red"

    def hover_enter_save(self, event):
        self.save_btn["bg"] = "blue"
    def hover_leave_save(self, event):
        self.save_btn["bg"] = "red"

    def hover_enter_back(self, event):
        self.back_btn["bg"] = "blue"
    def hover_leave_back(self, event):
        self.back_btn["bg"] = "red"

class decryption:
    def __init__(self,master):
        print("decryption part!!")
        self.master = master
        self.master.geometry("410x310")
        self.master.resizable(False, False)
        self.master.title("#Decryption#")

        # creating a label and entry for the encryption
        self.frame_headers = ttk.Frame(self.master)
        self.frame_bodys = ttk.Frame(self.master)

        # creasting icon\
        self.master.iconbitmap('icon/decrypted.ico')

        # creating a styles\
        self.style=ttk.Style()
        self.style.configure("body.TLabel",background='#783af2')
        self.style.configure("design.TLabel",background='#1e0257')
        self.style.configure("header.TLabel",background='blue')

        self.style.configure('TFrame',background='red')
        #creating a background
        self.back_grod = PhotoImage(file='rsz_rdblu4.gif')
        self.img_label = ttk.Label(self.frame_bodys, image=self.back_grod)
        self.img_label.place(x=0, y=0)

        # creating a label and entry
        self.label_head = ttk.Label(self.frame_headers, text="DECRYPTION!!!", font=('Showcard Gothic', 23, 'bold'),style='header.TLabel')
        self.img_header = PhotoImage(file='img_window2/rsz_window2_back.gif').subsample(2, 2)
        self.img_header_ = ttk.Label(self.frame_headers, image=self.img_header)


        self.label_decrypt = ttk.Label(self.frame_bodys, text="Text:",font='Stencil',style='body.TLabel')
        self.label_key = ttk.Label(self.frame_bodys, text="Key:",font='Stencil',style='body.TLabel')
        self.label_decrypted = ttk.Label(self.frame_bodys, text="DECRYPTED text:",font='Stencil',style='body.TLabel')

        self.entry_decrypt = ttk.Entry(self.frame_bodys, width=20,font='Georgia')
        self.entry_key = ttk.Entry(self.frame_bodys, width=20,font='Georgia')
        self.entry_decrypted = ttk.Entry(self.frame_bodys, width=20,font='Georgia',state="disabled")

        #creating images for btn
        self.generate_img = PhotoImage(file='btn_imges/generate.gif').subsample(2, 2)
        self.clear_img = PhotoImage(file='btn_imges/rsz_reset.gif').subsample(2, 2)
        self.save_img = PhotoImage(file='btn_imges/save.gif').subsample(2, 2)
        self.back_img = PhotoImage(file='btn_imges/back btn.gif').subsample(2, 2)


        # creating a button
        self.decrypt_btn = Button(self.frame_bodys, text="Generate", bg='red', fg='white',command=self.decryption_
                                  , image=self.generate_img, compound=RIGHT,activebackground='#8800d6')
        self.clear_btn = Button(self.frame_bodys, text="Clear", bg='red', fg='white',command=self.clear_
                                , image=self.clear_img, compound=RIGHT,activebackground='#8800d6'
                                )
        self.save_btn = Button(self.frame_bodys, text="Save", bg='red', fg='white',command=self.save_ ,
                               image=self.save_img,compound=RIGHT,activebackground='#8800d6')
        self.back_btn = Button(self.frame_bodys, text="Back", bg='red', fg='white',command=self.back_,activebackground='#8800d6')

        # creating a hover for button
        self.decrypt_btn.bind("<Enter>", self.hover_enter_decrypt)
        self.decrypt_btn.bind("<Leave>", self.hover_leave_decrypt)

        self.clear_btn.bind("<Enter>", self.hover_enter_clear)
        self.clear_btn.bind("<Leave>", self.hover_leave_clear)

        self.save_btn.bind("<Enter>", self.hover_enter_save)
        self.save_btn.bind("<Leave>", self.hover_leave_save)

        self.back_btn.bind("<Enter>", self.hover_enter_back)
        self.back_btn.bind("<Leave>", self.hover_leave_back)

        # griding and packing   command=self.back_
        self.frame_headers.pack()
        self.frame_bodys.pack()

        self.label_head.grid(row=0, column=0)
        self.img_header_.grid(row=0,column=1)
  #      self.label_design.grid(row=1)

        self.label_decrypt.grid(row=0, column=0, padx=20, pady=20)
        self.label_key.grid(row=1, column=0, padx=20, pady=20)
        self.label_decrypted.grid(row=5, column=1, padx=5, pady=5, ipadx=4, sticky='w')

        self.entry_decrypt.grid(row=0, column=1, padx=20, pady=20)
        self.entry_key.grid(row=1, column=1, padx=20, pady=20)
        self.entry_decrypted.grid(row=6, column=1, padx=5, pady=5, sticky='w')
   #     self.label_design.grid(row=2, columnspan=3, padx=20, pady=5)
    #    self.label_design1.grid(row=4, columnspan=3, padx=20, pady=5)

        self.decrypt_btn.grid(row=3, column=1, padx=5, pady=10, sticky='n')
        self.clear_btn.grid(row=3, column=1, padx=5, pady=10, sticky='e')
        self.save_btn.grid(row=3, column=0, padx=50, pady=10, sticky='e')
        self.back_btn.grid(row=3, column=0, padx=5, pady=10, sticky='w')





    def decryption_(self):
        print("decrypting part")
        self.a = self.entry_decrypt.get()
        if (self.a == ''):
            self.engine = pyttsx3.init()
            self.engine.say("Please enter a text!!")
            self.engine.runAndWait()

        self.b = str(self.entry_key.get())
        if (self.b == ''):
            self.engine = pyttsx3.init()
            self.engine.say("Please enter a key!!")
            self.engine.runAndWait()
        if (self.a != ''):
            if (self.b != ''):
                self.engine = pyttsx3.init()
                self.engine.say("Your text has been succsessfully Decrypted")
                self.engine.runAndWait()
                self.entry_decrypted.configure(state="enabled")

        self.c = decryption_form.decrypt_(self.a,self.b)
        self.d = self.entry_decrypted.insert(0,self.c)


    def clear_(self):
        print("cleared")
        self.entry_decrypt.delete(0,END)
        self.entry_key.delete(0, END)
        self.entry_decrypted.delete(0, END)

    def save_(self):
        print("successfully saved!")
        self.file = filedialog.asksaveasfile(defaultextension='.txt',
                                             filetypes=[("Text file",".txt"),("Html file",".html"),
                                                                                ("all files",".*")])
        self.tim=str(datetime.datetime.now())
        self.filetext_decrypt=str(self.entry_decrypt.get())
        self.filetext_decrypted=str(self.entry_decrypted.get())
        self.file.write("DECRYPTING TEXT:")
        self.file.write('\n')
        self.file.write(self.filetext_decrypt)
        self.file.write('\n')
        self.file.write('DECRYPTED TEXT:')
        self.file.write('\n')
        self.file.write(self.filetext_decrypted)
        self.file.write('\n')
        self.file.write(self.tim)
        self.file.close()


    def back_(self):
        print("Pressed back!")
        messagebox.showinfo(title="back error",message="The back option is under development so,press x and go back!")


        self.engine = pyttsx3.init()
        self.engine.say("the back option won't work it is under development please close the current tab and go on furter "
                            "process!")
        self.engine.runAndWait()

        # creating a function for hover

    def hover_enter_decrypt(self, event):
        self.decrypt_btn["bg"] = "blue"

    def hover_leave_decrypt(self, event):
        self.decrypt_btn["bg"] = "red"

    def hover_enter_clear(self, event):
        self.clear_btn["bg"] = "blue"

    def hover_leave_clear(self, event):
        self.clear_btn["bg"] = "red"

    def hover_enter_save(self, event):
        self.save_btn["bg"] = "blue"

    def hover_leave_save(self, event):
        self.save_btn["bg"] = "red"

    def hover_enter_back(self, event):
        self.back_btn["bg"] = "blue"

    def hover_leave_back(self, event):
        self.back_btn["bg"] = "red"

#increase the widht and height of encry and decrypt   doner
#turn on the voice mod        done
#design the decrypt part!!        done
#nedd to create a bind part for encrypted part!!!    done
#cursor!!!    done
#create a hover for encryption and decryption butoons and customize   done
#creation hover for each button!!!   done

def main():
    root=Tk()
    app=window1(root)

    root.mainloop()

if __name__ == "__main__": main()

