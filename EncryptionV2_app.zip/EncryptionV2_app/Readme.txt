<------------------------------------------------->
hello users!!!!

>Run the Encryption_v2 Application 
>Not the Encryption_v2.py  
>Run and Enjoy!!!

<==================================================>

		-By Akatsuki Development and Organisation
