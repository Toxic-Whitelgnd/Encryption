<------------------------------------------------->
hello users!!!!

>Run the Encryption_v2 Application 
>If you dont have account  
>Create a account by using signup
>Enter a valid email
>If u have antivirus it will ask for "This app is asking for Accessing the internet" Please allow :]
>you will getting OTP verification
>Then Login
> :)  XD

<==================================================>

		-By Akatsuki Development and Organisation
					~Pain



"The world shall know the pain"
